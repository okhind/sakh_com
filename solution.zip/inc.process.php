<?php
    include_once("class.user.php");
    $dsn = 'mysql:dbname='.$db_config['name'].';host='.$db_config['host'];
    $dbh = null;
    try {
        $dbh = new PDO($dsn, $db_config['user'], $db_config['pass']);    
        $dbh->query("SET NAMES 'utf8'");
    } catch (PDOException $e) {
        die( 'Подключение не удалось: ' . $e->getMessage());
    }
    global $dbh;
?>
<html>
<head>
<title></title>
</head>
<body>
<?php
    if (isset($_POST['amount'])) {
        $sender = User::getInstance($_POST['sender']);
        $sender->remit($_POST['receiver'], $_POST['amount']);
    }
    if (isset($_GET['remit'])) {
        $sender = User::getInstance($_GET['remit']);
        $users = User::getAll();
        ?>
        <form action="/?show=all" method="POST">
        <input type="hidden" name="sender" value="<?=$sender->ID?>">
        Переводимая сумма
        <input name="amount" placeholder="Не более <?=$sender->getBalance()?>">
        <br>
        Кому
        <select name="receiver">
        <?php
        foreach($users as $user) {
            if ($user->ID != $sender->ID) {
                ?>
                <option value="<?=$user->ID?>"><?=$user->Name.' '.$user->MiddleName.' '.$user->SurName?></option>
                <?php
            }
        }
        ?>
        </select>
        <br>
        <input type='reset'>
        <input type='submit'>
        </form>
        <?php
    }
    else {
        $users = User::getAllWithBalance();
        if (count($users) > 0) {
            ?>
            <table border="1">
                <tr>
                    <th>№№</th>
                    <th>ФИО</th>
                    <th>Баланс</th>
                    <th>Перевод</th>
                </tr>
            <?php
            foreach($users as $k => $user) {
                ?>
                <tr>
                    <td><?=$k + 1?></td>
                    <td><?=$user['Name'].' '.$user['MiddleName'].' '.$user['SurName']?></td>
                    <td><?=$user['balance']?></td>
                    <td><a href="/?remit=<?=$user['ID']?>">Перевод</a></td>
                </tr>
                <?php
            }
        }
    }
?>
</body>
</html>

