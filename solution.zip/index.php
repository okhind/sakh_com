<?php
session_start();
include_once("inc.config.php");
include_once("inc.process.php");
