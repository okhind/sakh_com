<?php
// Configuration of database connection
$db_config['user'] = 'root';      // db user name
$db_config['pass'] = '';          // db user password
$db_config['name'] = 'sakh_com';  // db name
$db_config['host'] = 'localhost'; // db host name
