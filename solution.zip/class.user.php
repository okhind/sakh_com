<?php

class User {
    
    var $ID;
    var $SurName;
    var $Name;
    var $MiddleName;

    public static function getInstance($ID) {
        global $dbh;
        $res = $dbh->query("SELECT * FROM users WHERE ID = ".$ID);
        if ($res) {
            return $res->fetchAll(PDO::FETCH_CLASS, "User")[0];
        }
        return null;
    }

    public static function getAll() {
        global $dbh;
        $res = $dbh->query("SELECT * FROM users");
        if ($res) {
            return $res->fetchAll(PDO::FETCH_CLASS, "User");
        }
        return null;
    }

    public static function getAllWithBalance() {
        global $dbh;
        $res = $dbh->query("SELECT u.*, ub.balance FROM users u INNER JOIN user_balances ub ON u.ID = ub.userID");
        if ($res) {
            return $res->fetchAll(PDO::FETCH_ASSOC);
        }
        return null;
    }

    public function getBalance() {
        global $dbh;
        $res = $dbh->query("SELECT balance FROM user_balances WHERE userID = ".$this->ID);
        if ($res) {
             return $res->fetchAll()[0]['balance'];
        }
        return null;
    }

    public function remit($recID, $amount) {
        global $dbh;
        $bal = $this->getBalance();
        if ($bal < $amount) {
            throw new Exception("Недостаточно средств. На балансе пользователя имеется ".$bal.". Для перевода запрошено ".$amount);
        }
        $dbh->beginTransaction();
        try {
            $dbh->exec("INSERT INTO remittance_log (senderID, recID, event_date, amount) VALUES (".$this->ID.", ".$recID.", now(), ".$amount.")");
            $dbh->exec("UPDATE user_balances SET balance = balance - ".$amount." WHERE userID = ".$this->ID);
            $dbh->exec("UPDATE user_balances SET balance = balance + ".$amount." WHERE userID = ".$recID);
            $dbh->commit();
        }
        catch(PDOException $e) {
            $dbh->rollback();
        }
        
    }


}
